$('.slider').slick({
  infinite:true,
  slideToshow:1,
  slideToscroll:1
});
